#ifndef elf32_h
#define elf32_h

#ifndef UNW_ELF_CLASS
# define UNW_ELF_CLASS UNW_ELFCLASS32
#endif
#include "elfxx.h"

#endif /* elf32_h */
